"""Async circuit breaker for upstream node health tracking (improved).

This version extends the original circuit breaker by tracking the timestamp of
the last probe in the HALF_OPEN state. This ensures that a HALF_OPEN node
does not get spammed with probes — instead, probes are rate‑limited by
``probe_interval_s``. When a node transitions from ``OPEN`` to ``HALF_OPEN``,
the ``last_probe_ts`` is reset. During ``HALF_OPEN`` the first call will be
allowed immediately and subsequent calls will only be allowed once the
specified interval has elapsed.  See the ``is_available`` docstring for
details.

States:
  CLOSED    — normal operation, requests pass through
  OPEN      — node is disabled after N consecutive failures; all requests
              short‑circuit
  HALF_OPEN — cooldown expired, one probe request is allowed to test recovery

Transitions:
  CLOSED → OPEN:      consecutive failures >= threshold
  OPEN → HALF_OPEN:   cooldown_s elapsed
  HALF_OPEN → CLOSED: probe succeeds
  HALF_OPEN → OPEN:   probe fails (reset cooldown)

The improvements in this file address an edge case in the original
implementation where nodes in HALF_OPEN state could be hammered with
concurrent probes, defeating the purpose of a controlled recovery phase.
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from enum import Enum
from typing import Dict


class CBState(str, Enum):
    """Circuit breaker state machine values."""

    CLOSED = "CLOSED"
    OPEN = "OPEN"
    HALF_OPEN = "HALF_OPEN"


@dataclass
class _NodeBreaker:
    """Internal per‑node circuit breaker state and metrics.

    ``last_probe_ts`` tracks when the last probe was allowed during the
    ``HALF_OPEN`` state. This prevents unlimited probes from being issued
    immediately after a node cools down.
    """

    state: CBState = CBState.CLOSED
    consecutive_failures: int = 0
    last_failure_ts: float = 0.0
    opened_at: float = 0.0
    total_failures: int = 0
    total_successes: int = 0
    # NEW: timestamp of the most recent probe allowed in HALF_OPEN
    last_probe_ts: float = 0.0


class CircuitBreakerRegistry:
    """Manages circuit breakers for multiple upstream nodes.

    Parameters
    ----------
    failure_threshold: int
        Number of consecutive failures required to trip the breaker into OPEN.
    cooldown_s: float
        Number of seconds the breaker will remain OPEN before allowing a probe
        in HALF_OPEN state.
    probe_interval_s: float
        Minimum time between probes when the breaker is in HALF_OPEN. If zero
        or negative, probes will be allowed on every call (restoring the
        original behaviour).
    """

    def __init__(
        self,
        failure_threshold: int = 5,
        cooldown_s: float = 60.0,
        probe_interval_s: float = 15.0,
    ) -> None:
        self.failure_threshold = failure_threshold
        self.cooldown_s = cooldown_s
        self.probe_interval_s = float(probe_interval_s)
        self._breakers: Dict[str, _NodeBreaker] = {}
        self._lock = asyncio.Lock()

    def _get(self, node: str) -> _NodeBreaker:
        if node not in self._breakers:
            self._breakers[node] = _NodeBreaker()
        return self._breakers[node]

    async def is_available(self, node: str) -> bool:
        """Check if a node is available for requests.

        The breaker returns ``True`` in the following cases:

        * The node is in ``CLOSED`` state.
        * The node is in ``OPEN`` and the cooldown has elapsed; the state
          transitions to ``HALF_OPEN`` and a probe is allowed.
        * The node is in ``HALF_OPEN`` and either ``probe_interval_s`` is
          non‑positive (legacy behaviour) or sufficient time has passed since
          the last allowed probe.

        Otherwise (``OPEN`` before cooldown or ``HALF_OPEN`` too soon
        after the last probe) the method returns ``False`` to short‑circuit
        requests.
        """
        async with self._lock:
            cb = self._get(node)
            now = time.monotonic()

            if cb.state == CBState.CLOSED:
                return True

            if cb.state == CBState.OPEN:
                elapsed = now - cb.opened_at
                if elapsed >= self.cooldown_s:
                    cb.state = CBState.HALF_OPEN
                    cb.last_probe_ts = 0.0  # reset probe timer
                    # A probe is allowed immediately when we flip to HALF_OPEN
                    cb.last_probe_ts = now
                    return True
                return False

            # HALF_OPEN: allow a probe if interval has elapsed
            if self.probe_interval_s <= 0:
                # legacy: allow every probe without gating
                cb.last_probe_ts = now
                return True

            if now - cb.last_probe_ts >= self.probe_interval_s:
                cb.last_probe_ts = now
                return True
            return False

    async def record_success(self, node: str) -> None:
        """Record a successful call. Resets breaker to CLOSED."""
        async with self._lock:
            cb = self._get(node)
            cb.consecutive_failures = 0
            cb.total_successes += 1
            if cb.state in (CBState.HALF_OPEN, CBState.OPEN):
                cb.state = CBState.CLOSED

    async def record_failure(self, node: str) -> None:
        """Record a failed call. May trip breaker to OPEN."""
        async with self._lock:
            cb = self._get(node)
            cb.consecutive_failures += 1
            cb.total_failures += 1
            cb.last_failure_ts = time.monotonic()

            if cb.state == CBState.HALF_OPEN:
                # Probe failed: back to OPEN and reset cooldown
                cb.state = CBState.OPEN
                cb.opened_at = time.monotonic()
                return

            if cb.consecutive_failures >= self.failure_threshold:
                cb.state = CBState.OPEN
                cb.opened_at = time.monotonic()

    async def get_status(self, node: str) -> dict:
        """Return human‑readable status for a node."""
        async with self._lock:
            cb = self._get(node)
            return {
                "node": node,
                "state": cb.state.value,
                "consecutive_failures": cb.consecutive_failures,
                "total_failures": cb.total_failures,
                "total_successes": cb.total_successes,
            }

    async def get_all_status(self) -> list[dict]:
        """Return status for all tracked nodes."""
        async with self._lock:
            return [
                {
                    "node": name,
                    "state": cb.state.value,
                    "consecutive_failures": cb.consecutive_failures,
                    "total_failures": cb.total_failures,
                    "total_successes": cb.total_successes,
                }
                for name, cb in self._breakers.items()
            ]

    async def force_close(self, node: str) -> None:
        """Manually reset a breaker to CLOSED (admin action)."""
        async with self._lock:
            cb = self._get(node)
            cb.state = CBState.CLOSED
            cb.consecutive_failures = 0

    async def force_open(self, node: str) -> None:
        """Manually open a breaker (admin action)."""
        async with self._lock:
            cb = self._get(node)
            cb.state = CBState.OPEN
            cb.opened_at = time.monotonic()