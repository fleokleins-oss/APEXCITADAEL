"""Improved confluence engine with LiqMap role.

This module is a copy of the original ``apex_common.confluence`` with
one key change: the ``DEFAULT_NODE_ROLES`` mapping includes an entry
``"liqmap": [ROLE_RISK]`` so that the LiqMap service contributes to
risk sizing rather than direction or survival. All other logic is
unchanged. Refer to the original module for detailed documentation
about gate behaviour and evaluation order.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Literal, Optional


Action = Literal["EXECUTE", "WAIT", "KILL"]
Side = Literal["LONG", "SHORT", "NONE"]


@dataclass
class NodeSignal:
    """Standardized signal from any upstream node."""
    node: str
    action: Action = "WAIT"
    side: Side = "NONE"
    confidence: float = 0.0
    available: bool = True
    metadata: Dict = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.confidence = max(0.0, min(1.0, float(self.confidence)))


class ConfluenceMode(str, Enum):
    AND = "AND"
    OR = "OR"
    MAJORITY = "MAJORITY"
    WEIGHTED = "WEIGHTED"


@dataclass
class GateResult:
    """Result of a single gate evaluation."""
    name: str
    passed: bool
    reason: str


@dataclass
class ConfluenceResult:
    """Full result of confluence evaluation across all gates."""
    action: Action
    side: Side
    confidence: float
    risk_multiplier: float
    gates: List[GateResult]
    signals: List[NodeSignal]
    reasoning: List[str]

    @property
    def should_execute(self) -> bool:
        return self.action == "EXECUTE"


# ──── Gate Roles ────
ROLE_SURVIVAL = "survival"
ROLE_DIRECTION = "direction"
ROLE_RISK = "risk"

# Default node → role mapping (with LiqMap risk node)
DEFAULT_NODE_ROLES: Dict[str, List[str]] = {
    # v2 legacy nodes
    "brain": [ROLE_DIRECTION, ROLE_RISK, ROLE_SURVIVAL],
    "shadowglass": [ROLE_DIRECTION],

    # v3 nodes
    "spoofhunter": [ROLE_DIRECTION, ROLE_SURVIVAL],
    "newtonian": [ROLE_DIRECTION],
    "narrative": [ROLE_DIRECTION],
    "antirug_v3": [ROLE_SURVIVAL],
    "dreamer": [ROLE_DIRECTION, ROLE_RISK],
    "econopredator": [],  # data-only
    "jito_spoof": [],
    # NEW: LiqMap risk node
    "liqmap": [ROLE_RISK],
    # NEW: Birdeye directional node
    "birdeye": [ROLE_DIRECTION],
}


def _clamp(x: float, lo: float, hi: float) -> float:
    return lo if x < lo else hi if x > hi else x


class ConfluenceEngine:
    """Evaluates multiple node signals through Boolean confluence gates."""

    def __init__(
        self,
        mode: ConfluenceMode = ConfluenceMode.MAJORITY,
        min_confidence: float = 0.55,
        node_weights: Optional[Dict[str, float]] = None,
        node_roles: Optional[Dict[str, List[str]]] = None,
        required_nodes: Optional[List[str]] = None,
        fallback_on_timeout: Action = "WAIT",
    ) -> None:
        self.mode = mode
        self.min_confidence = min_confidence
        self.node_weights = node_weights or {}
        self.node_roles = node_roles or DEFAULT_NODE_ROLES
        self.required_nodes = set(required_nodes or [])
        self.fallback_on_timeout = fallback_on_timeout

    def _get_roles(self, node: str) -> List[str]:
        return self.node_roles.get(node, [])

    def _get_weight(self, node: str) -> float:
        return float(self.node_weights.get(node, 1.0))

    def _signals_with_role(self, signals: List[NodeSignal], role: str) -> List[NodeSignal]:
        return [s for s in signals if role in self._get_roles(s.node) and s.available]

    # ──── SURVIVAL GATE ────
    def _eval_survival(self, signals: List[NodeSignal]) -> GateResult:
        survival_nodes = self._signals_with_role(signals, ROLE_SURVIVAL)
        if not survival_nodes:
            return GateResult("SURVIVAL", True, "No survival nodes available; pass by default")
        killers = [s for s in survival_nodes if s.action == "KILL"]
        if killers:
            names = ", ".join(s.node for s in killers)
            return GateResult("SURVIVAL", False, f"KILL from: {names}")
        return GateResult("SURVIVAL", True, f"All {len(survival_nodes)} survival nodes passed")

    # ──── DIRECTION GATE ────
    def _eval_direction(self, signals: List[NodeSignal]) -> tuple[GateResult, Side]:
        dir_nodes = self._signals_with_role(signals, ROLE_DIRECTION)
        executing = [s for s in dir_nodes if s.action == "EXECUTE" and s.side in ("LONG", "SHORT")]
        if not executing:
            return GateResult("DIRECTION", False, "No directional signals (all WAIT/KILL)"), "NONE"
        longs = [s for s in executing if s.side == "LONG"]
        shorts = [s for s in executing if s.side == "SHORT"]
        total = len(executing)
        if self.mode == ConfluenceMode.AND:
            if len(longs) == total:
                return GateResult("DIRECTION", True, f"AND: all {total} agree LONG"), "LONG"
            if len(shorts) == total:
                return GateResult("DIRECTION", True, f"AND: all {total} agree SHORT"), "SHORT"
            return GateResult("DIRECTION", False, f"AND: split {len(longs)}L/{len(shorts)}S of {total}"), "NONE"
        if self.mode == ConfluenceMode.OR:
            if longs and shorts:
                return GateResult("DIRECTION", False, "OR: conflicting LONG/SHORT"), "NONE"
            if longs:
                return GateResult("DIRECTION", True, "OR: at least one LONG"), "LONG"
            return GateResult("DIRECTION", True, "OR: at least one SHORT"), "SHORT"
        if self.mode == ConfluenceMode.MAJORITY:
            if len(longs) > len(shorts):
                return GateResult("DIRECTION", True, f"MAJ: {len(longs)}/{total} LONG"), "LONG"
            if len(shorts) > len(longs):
                return GateResult("DIRECTION", True, f"MAJ: {len(shorts)}/{total} SHORT"), "SHORT"
            return GateResult("DIRECTION", False, f"MAJ: tie {len(longs)} LONG vs {len(shorts)} SHORT"), "NONE"
        # WEIGHTED
        long_score = sum(self._get_weight(s.node) * s.confidence for s in longs)
        short_score = sum(self._get_weight(s.node) * s.confidence for s in shorts)
        if long_score > short_score:
            return GateResult("DIRECTION", True, f"WT: LONG score {long_score:.2f} > {short_score:.2f}"), "LONG"
        if short_score > long_score:
            return GateResult("DIRECTION", True, f"WT: SHORT score {short_score:.2f} > {long_score:.2f}"), "SHORT"
        return GateResult("DIRECTION", False, f"WT: tie score {long_score:.2f} vs {short_score:.2f}"), "NONE"

    # ──── CONFIDENCE GATE ────
    def _eval_confidence(self, signals: List[NodeSignal], side: Side) -> GateResult:
        if side not in ("LONG", "SHORT"):
            return GateResult("CONFIDENCE", False, "No execution side selected"), 0.0
        dir_nodes = [s for s in self._signals_with_role(signals, ROLE_DIRECTION) if s.action == "EXECUTE" and s.side == side]
        if not dir_nodes:
            return GateResult("CONFIDENCE", False, "No directional nodes for selected side"), 0.0
        if self.mode == ConfluenceMode.WEIGHTED:
            total_weight = sum(self._get_weight(s.node) for s in dir_nodes)
            conf = sum(self._get_weight(s.node) * s.confidence for s in dir_nodes) / max(total_weight, 1e-9)
        else:
            conf = sum(s.confidence for s in dir_nodes) / len(dir_nodes)
        passed = conf >= self.min_confidence
        reason = f"Conf {conf:.2f} {'>=' if passed else '<'} threshold {self.min_confidence:.2f}"
        return GateResult("CONFIDENCE", passed, reason), conf

    # ──── RISK GATE ────
    def _eval_risk(self, signals: List[NodeSignal]) -> tuple[GateResult, float]:
        risk_nodes = self._signals_with_role(signals, ROLE_RISK)
        if not risk_nodes:
            return GateResult("RISK", True, "No risk nodes available; using default"), 1.0
        multipliers = [s.metadata.get("risk_multiplier", 1.0) for s in risk_nodes]
        rm = 1.0
        for m in multipliers:
            try:
                m = float(m)
            except Exception:
                m = 1.0
            rm *= m
        rm = _clamp(rm, 0.0, 1.0)
        return GateResult("RISK", True, f"Combined risk multiplier {rm:.3f}"), rm

    # ──── MASTER EVALUATION ────
    def evaluate(self, signals: List[NodeSignal]) -> ConfluenceResult:
        reasoning: List[str] = []
        gates: List[GateResult] = []
        # 1. Survival gate
        gr = self._eval_survival(signals)
        gates.append(gr)
        if not gr.passed:
            return ConfluenceResult(action="KILL", side="NONE", confidence=0.0, risk_multiplier=0.0, gates=gates, signals=signals, reasoning=reasoning)
        # 2. Direction gate
        gr, side = self._eval_direction(signals)
        gates.append(gr)
        if not gr.passed:
            return ConfluenceResult(action="WAIT", side="NONE", confidence=0.0, risk_multiplier=0.0, gates=gates, signals=signals, reasoning=reasoning)
        # 3. Confidence gate
        gr, conf = self._eval_confidence(signals, side)
        gates.append(gr)
        if not gr.passed:
            return ConfluenceResult(action="WAIT", side="NONE", confidence=conf, risk_multiplier=0.0, gates=gates, signals=signals, reasoning=reasoning)
        # 4. Risk gate
        gr, rm = self._eval_risk(signals)
        gates.append(gr)
        return ConfluenceResult(action="EXECUTE", side=side, confidence=conf, risk_multiplier=rm, gates=gates, signals=signals, reasoning=reasoning)