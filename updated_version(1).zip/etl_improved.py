"""
Improved ETL script for loading CSV data into a PostgreSQL database.

This version introduces the following enhancements over the original script:

* Consolidated environment variable retrieval into a dedicated function with
  clearer error messages and defaults.
* Added a `get_conninfo` helper to build the connection string, reducing
  duplication and improving readability.
* Extracted CSV loading and validation into a separate `load_data` function
  that enforces required columns, drops missing values and performs
  type coercion before ingestion.
* Encapsulated the insertion logic into an `insert_rows` helper that
  operates directly on the DataFrame and uses `executemany` for bulk
  insertion.
* Introduced a generic `run_sql` helper that executes any SQL file in
  the `sql` directory, improving reusability.
* Added basic exception handling to ensure the transaction is rolled back
  on error and to surface issues clearly.
* Printed the result metrics in a single line for easier parsing.

Note: For very large datasets you might consider using PostgreSQL's COPY
interface via `psycopg`'s `copy` helpers instead of `executemany`, which
can significantly improve performance. However, for small to medium sized
datasets the current approach remains adequate and easier to understand.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Iterable, Tuple

import pandas as pd
import psycopg
from dotenv import load_dotenv

# Project structure constants. Assumes this script is located in `src/` and
# that the project root contains `data/` and `sql/` directories.
ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "sample.csv"
SQL_DIR = ROOT / "sql"

def env(name: str, default: str | None = None) -> str:
    """Retrieve an environment variable or raise an error if missing.

    Parameters
    ----------
    name : str
        The name of the environment variable to retrieve.
    default : str | None, optional
        Default value to use if the environment variable is unset. If None,
        the variable is considered mandatory and a RuntimeError is raised
        when absent.

    Returns
    -------
    str
        The value of the environment variable.
    """
    value = os.getenv(name, default)
    if value in (None, ""):
        raise RuntimeError(f"Missing environment variable: {name}")
    return value

def get_conninfo() -> str:
    """Construct a PostgreSQL connection string from environment variables."""
    host = env("POSTGRES_HOST", "localhost")
    port = env("POSTGRES_PORT", "5432")
    dbname = env("POSTGRES_DB", "etl_db")
    user = env("POSTGRES_USER", "etl_user")
    password = env("POSTGRES_PASSWORD", "etl_pass")
    return f"host={host} port={port} dbname={dbname} user={user} password={password}"

def connect() -> psycopg.Connection:
    """Create a new PostgreSQL connection using psycopg."""
    return psycopg.connect(get_conninfo())

def run_sql(cur: psycopg.Cursor, sql_file: Path) -> None:
    """Execute the SQL statements contained in the given file.

    Parameters
    ----------
    cur : psycopg.Cursor
        The database cursor used to execute the statements.
    sql_file : Path
        Path to the SQL file to be executed.
    """
    sql = sql_file.read_text(encoding="utf-8")
    cur.execute(sql)

def load_data(csv_path: Path) -> pd.DataFrame:
    """Load and validate the CSV data.

    The function enforces presence of required columns, drops rows with
    missing values in these columns, coerces data types and parses
    timestamp fields to timezone-aware datetime objects.

    Parameters
    ----------
    csv_path : Path
        Path to the CSV file to load.

    Returns
    -------
    DataFrame
        Cleaned and typed DataFrame ready for insertion.
    """
    df = pd.read_csv(csv_path)
    required_columns = ["event_id", "user_id", "event_type", "event_ts"]
    missing_columns = set(required_columns) - set(df.columns)
    if missing_columns:
        raise ValueError(f"CSV missing columns: {sorted(missing_columns)}")

    # Drop rows with missing required values
    df = df.dropna(subset=required_columns)
    # Coerce numeric and categorical types
    df = df.astype({"event_id": "int64", "user_id": "int64", "event_type": "string"})
    # Parse timestamps to timezone-aware datetimes
    df["event_ts"] = pd.to_datetime(df["event_ts"], utc=True, errors="coerce")
    df = df.dropna(subset=["event_ts"])
    return df

def insert_rows(cur: psycopg.Cursor, df: pd.DataFrame) -> None:
    """Insert rows from the given DataFrame into the `public.events` table.

    Parameters
    ----------
    cur : psycopg.Cursor
        The database cursor used for insertion.
    df : DataFrame
        DataFrame containing the rows to insert.
    """
    rows: Iterable[Tuple] = df.itertuples(index=False, name=None)
    cur.executemany(
        "INSERT INTO public.events (event_id, user_id, event_type, event_ts) VALUES (%s, %s, %s, %s)",
        rows,
    )

def main() -> None:
    """Entry point for the ETL process."""
    # Load environment variables from .env at project root
    load_dotenv(ROOT / ".env")

    # Load and clean CSV data
    df = load_data(DATA_PATH)

    try:
        with connect() as conn:
            with conn.cursor() as cur:
                # Step 1: Ensure table exists
                run_sql(cur, SQL_DIR / "01_create_table.sql")
                # Step 2: Bulk insert new rows
                insert_rows(cur, df)
                # Step 3: Deduplicate existing data
                run_sql(cur, SQL_DIR / "02_dedupe.sql")
                # Step 4: Compute metrics
                run_sql(cur, SQL_DIR / "03_metric.sql")
                total_rows, distinct_users = cur.fetchone()
            # Commit transaction only after all operations succeed
            conn.commit()
    except Exception as exc:
        # Roll back on error and re-raise for visibility
        try:
            conn.rollback()
        except Exception:
            pass
        raise RuntimeError(f"ETL failed: {exc}") from exc

    print(f"✅ Done - total_rows={total_rows}, distinct_users={distinct_users}")

if __name__ == "__main__":
    main()
