"""
Liq Cluster Mapping (Reactive) — Binance USDM demo/live

This microservice detects large liquidity "walls" in the Binance perpetual
order book (via the futures depth endpoint) and computes a risk multiplier
that scales position sizing. The goal is to *react* to existing clusters of
orders rather than attempt to move price into them. It's intended as a
protective risk node in a confluence engine rather than a directional signal.

For each symbol, the service fetches the current mark price and funding rate
via the ``/fapi/v1/premiumIndex`` endpoint and the L2 order book via
``/fapi/v1/depth``. It then filters for the largest bids and asks by
notional size using a configurable quantile (``WALL_Q``) and minimum
notional threshold. The risk multiplier scales between 1.0 (no reduction)
and ``1 - MAX_RISK_REDUCTION`` when price is very close to a huge wall.

Environment variables (with defaults):

``BINANCE_FAPI_BASE``
  Base URL for the futures API (demo: ``https://demo-fapi.binance.com`` or
  production: ``https://fapi.binance.com``).

``LIQMAP_DEPTH_LIMIT``
  Number of order book levels to fetch per side (default: 500).

``LIQMAP_TOPK``
  Number of largest walls to keep per side after filtering (default: 8).

``LIQMAP_WALL_Q``
  Quantile (0–1) threshold for determining which orders count as "big".
  The n‑th quantile is computed separately for bids and asks, and any order
  above the resulting notional cutoff or ``MIN_NOTIONAL`` is considered a
  wall.  Default: 0.995.

``LIQMAP_NEAR_BPS``
  Basis‑point distance from the mark price considered "near" a wall.
  Distances closer than this threshold will produce higher risk. Default: 18.

``LIQMAP_MIN_NOTIONAL``
  Absolute notional threshold for considering an order a wall. This
  protects against erroneously low quantile cutoffs in thin markets.
  Default: 250_000 (i.e. 250k USDT).

``LIQMAP_MAX_RISK_REDUCTION``
  Maximum proportion of risk to reduce when at very close proximity to a
  giant wall. For example, if set to 0.65, the risk multiplier can go as
  low as 0.35. Default: 0.65.

Endpoints:

  GET /liqmap/{symbol}
    Returns a JSON object with keys:

      ``node``
        Always "liqmap".

      ``action``
        Always "WAIT" (this is a risk node, not a directional node).

      ``side``
        Always "NONE".

      ``confidence``
        Always 1.0 (confidence doesn't apply to risk sizing here).

      ``risk_multiplier``
        A float between (1 - MAX_RISK_REDUCTION) and 1.0 inclusive.

      ``metadata``
        Additional information, including the nearest wall and whether the
        market is near a wall.

This service is designed for demonstration purposes and to show how
market microstructure data can inform risk sizing. It should be run
separately from the orchestrator and invoked via a node adapter.
"""

from __future__ import annotations

import math
import os
from dataclasses import dataclass
from typing import Any, Dict, List, Tuple

import httpx
from fastapi import FastAPI, HTTPException


app = FastAPI(title="LiqMap — Reactive Cluster Risk")


# Read configuration from environment
FAPI_BASE = os.getenv("BINANCE_FAPI_BASE", "https://demo-fapi.binance.com").rstrip("/")
DEPTH_LIMIT = int(os.getenv("LIQMAP_DEPTH_LIMIT", "500"))
TOPK = int(os.getenv("LIQMAP_TOPK", "8"))
WALL_Q = float(os.getenv("LIQMAP_WALL_Q", "0.995"))
NEAR_BPS = float(os.getenv("LIQMAP_NEAR_BPS", "18"))
MIN_NOTIONAL = float(os.getenv("LIQMAP_MIN_NOTIONAL", "250000"))
MAX_RISK_REDUCTION = float(os.getenv("LIQMAP_MAX_RISK_REDUCTION", "0.65"))


def _clamp(x: float, lo: float, hi: float) -> float:
    """Clamp a value between lo and hi."""
    return lo if x < lo else hi if x > hi else x


def _sigmoid(x: float) -> float:
    """Compute logistic function for smooth scaling."""
    if x >= 0:
        z = math.exp(-x)
        return 1 / (1 + z)
    z = math.exp(x)
    return z / (1 + z)


@dataclass
class Wall:
    """Representation of a single order book wall."""

    side: str
    price: float
    qty: float
    notional: float
    dist_bps: float


async def _premium_index(http: httpx.AsyncClient, symbol: str) -> Tuple[float, float]:
    """Fetch mark price and last funding rate for a symbol."""
    r = await http.get(f"{FAPI_BASE}/fapi/v1/premiumIndex", params={"symbol": symbol}, timeout=4.5)
    r.raise_for_status()
    data = r.json()
    mark = float(data.get("markPrice") or 0.0)
    fr = float(data.get("lastFundingRate") or 0.0)
    if mark <= 0:
        raise HTTPException(status_code=502, detail="markPrice unavailable")
    return mark, fr


async def _depth(http: httpx.AsyncClient, symbol: str) -> Dict[str, Any]:
    """Fetch order book depth for a symbol."""
    r = await http.get(
        f"{FAPI_BASE}/fapi/v1/depth",
        params={"symbol": symbol, "limit": DEPTH_LIMIT},
        timeout=4.5,
    )
    r.raise_for_status()
    return r.json()


def _parse(side: str, levels: List[List[str]], mark: float) -> List[Wall]:
    """Convert raw order book levels into Wall objects."""
    out: List[Wall] = []
    for p_str, q_str in levels:
        p = float(p_str)
        q = float(q_str)
        notional = p * q
        if notional <= 0:
            continue
        dist_bps = abs((p - mark) / mark) * 10_000.0
        out.append(Wall(side=side, price=p, qty=q, notional=notional, dist_bps=dist_bps))
    return out


def _pick_walls(walls: List[Wall]) -> List[Wall]:
    """Select the largest walls based on a quantile cutoff and a minimum notional."""
    if not walls:
        return []
    notionals = sorted(w.notional for w in walls)
    idx = int(_clamp(int(len(notionals) * WALL_Q), 0, len(notionals) - 1))
    cutoff = max(notionals[idx], MIN_NOTIONAL)
    big = [w for w in walls if w.notional >= cutoff]
    big.sort(key=lambda w: (-w.notional, w.dist_bps))
    return big[:TOPK]


def _cluster_risk(mark: float, bid_walls: List[Wall], ask_walls: List[Wall]) -> Tuple[float, Dict[str, Any]]:
    """Calculate a risk factor (0–1) based on proximity and size of nearest wall."""
    candidates = bid_walls + ask_walls
    if not candidates:
        return 0.0, {"nearest": None, "near_wall": False}

    nearest = min(candidates, key=lambda w: w.dist_bps)

    # Proximity component (0–1): high if very close to the nearest wall
    prox = _sigmoid((NEAR_BPS - nearest.dist_bps) / max(1.0, NEAR_BPS / 4.0))
    # Strength component (0–1): scales with notional size relative to threshold
    strength = _clamp(math.log1p(nearest.notional / max(1.0, MIN_NOTIONAL)) / 3.0, 0.0, 1.0)
    # Combine to produce risk (0–1): proximity is weighted heavier when walls are huge
    risk = _clamp(prox * (0.35 + 0.65 * strength), 0.0, 1.0)

    meta = {
        "nearest": {
            "side": nearest.side,
            "price": nearest.price,
            "notional": nearest.notional,
            "dist_bps": nearest.dist_bps,
        },
        "near_wall": nearest.dist_bps <= NEAR_BPS,
        "prox": prox,
        "strength": strength,
    }
    return risk, meta


@app.get("/liqmap/{symbol}")
async def liqmap(symbol: str):
    """HTTP endpoint: return a risk multiplier and metadata for the given symbol."""
    sym = symbol.replace("/", "").replace(":", "").upper()

    async with httpx.AsyncClient() as http:
        mark, fr = await _premium_index(http, sym)
        book = await _depth(http, sym)

    bids = _parse("bid", book.get("bids") or [], mark)
    asks = _parse("ask", book.get("asks") or [], mark)

    bid_walls = _pick_walls(bids)
    ask_walls = _pick_walls(asks)

    risk, risk_meta = _cluster_risk(mark, bid_walls, ask_walls)

    # Convert risk (0–1) to a multiplicative risk factor between (1 - MAX_RISK_REDUCTION) and 1
    rm = 1.0 - (MAX_RISK_REDUCTION * risk)
    rm = _clamp(rm, 1.0 - MAX_RISK_REDUCTION, 1.0)

    return {
        "node": "liqmap",
        "action": "WAIT",
        "side": "NONE",
        "confidence": 1.0,
        "risk_multiplier": rm,
        "metadata": {
            "risk_multiplier": rm,
            "cluster_risk": risk,
            "markPrice": mark,
            "lastFundingRate": fr,
            "walls": {
                "bids": [
                    {"price": w.price, "notional": w.notional, "dist_bps": w.dist_bps}
                    for w in bid_walls
                ],
                "asks": [
                    {"price": w.price, "notional": w.notional, "dist_bps": w.dist_bps}
                    for w in ask_walls
                ],
            },
            **risk_meta,
        },
    }